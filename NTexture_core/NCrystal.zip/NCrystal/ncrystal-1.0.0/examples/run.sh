
. /home/chang/Desktop/NTexture/NCrystal/Instalacion/setup.sh
export PYTHONPATH="${PYTHONPATH}:/home/chang/Desktop/NTexture/NCrystal/ncrystal-1.0.0/libNCrystal.so"
python3 ncrystal_example_py