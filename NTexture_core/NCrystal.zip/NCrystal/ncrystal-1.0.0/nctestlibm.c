#include <math.h>
int main(int argc,char** argv) { (void)argv;double a=(exp)(argc+1.0); return (int)a; }
