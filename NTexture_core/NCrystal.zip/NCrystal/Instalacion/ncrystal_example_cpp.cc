#include "include/NCrystal/NCrystal.hh"
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <math.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <stdio.h>

using namespace std;

struct Salida {
    double h [48];
    double k [48];
    double l [48];
    double d_hkl [48];
    double mult [48];
    double F [48];
    double volume;
    unsigned n_atoms;
    double density;
    double temp;
    double temp_d;
    unsigned spacegroup;
    double lam [4031];
    double xsect [4031];
  };


int main (){


  Salida salida;

  //Crear el objeto Cfg solo con Bragg y con todas las componentes
  //NCrystal::MatCfg cfg("/home/chang/Desktop/Original/Instalacion/data/Cu_sg225.nxs;dcutoff=0.5; bkgd=none;temp=-48C");
  //NCrystal::MatCfg cfg_b("/home/chang/Desktop/Original/Instalacion/data/Cu_sg225.nxs;dcutoff=0.5;temp=-48C");
  //NCrystal::MatCfg cfg_g("/home/chang/Desktop/Original/Instalacion/data/Cu_sg225.nxs;dcutoff=0.5; bragg=false;temp=-48C");

  NCrystal::MatCfg cfg("/home/chang/Desktop/NText_1.0/NCrystal/Instalacion/data/Cu_sg225.ncmat;dcutoff=0.5; bkgd=none;temp=300K");
  NCrystal::MatCfg cfg_b("/home/chang/Desktop/NText_1.0/NCrystal/Instalacion/data/Cu_sg225.ncmat;dcutoff=0.5;temp=300K");
  NCrystal::MatCfg cfg_g("/home/chang/Desktop/NText_1.0/NCrystal/Instalacion/data/Cu_sg225.ncmat;dcutoff=0.5; bragg=false;temp=300K");


// Esto queda por si quiero agregar alguna direccion, no es importante si desprecio el bragg
/*
  cfg.set_mos(40.0*NCrystal::kArcSec);
  double c1[] = {5,1,1};
  double l1[] = {0,0,1};
  double c2[] = {0,-1,1};
  double l2[] = {0,1,0};
  cfg.set_dir1(true,c1,l1);
  cfg.set_dir2(true,c2,l2);
  */

  const NCrystal::Scatter * pc =  NCrystal::createScatter( cfg );        // Objeto de tipo Scatter solo con Bragg
  const NCrystal::Scatter * pc_b =  NCrystal::createScatter( cfg_b );    // Objeto de tipo Scatter con ambas compoenetes
  const NCrystal::Info * inf =  NCrystal::createInfo(cfg);               // Obejto de tipo Info para obetener la informacion cristalografica
  const NCrystal::Absorption * abs= NCrystal::createAbsorption(cfg_b);
  const NCrystal::Scatter * pc_g =  NCrystal::createScatter( cfg_g );

  // Calculo de la seccion eficaz sin considerar Bragg para Longitudes de ondas de 0-5A y en un arreglo 1X4031
  //double lam [4031];
  //double xsect [4031];
  //double xsect1 [4031];
  //double xsect2 [4031];
  //double xabs [4031];
  //FILE * file=fopen ("long_294.txt","r");
  //char line [100];
  //double lam;
  
  //ifstream file ("long_294.txt");
  FILE * file4=fopen ("secciones.txt","a");
  for (float i = 1; i < 10; i+=0.01)
  //std::string str;
  //while (std::getline(file,str))
  {
    //float aux=std::stof(str);
    //double ekin =NCrystal::wl2ekin(aux);
    
    double ekin = NCrystal::wl2ekin(i);
    
    //salida.lam[i]=9.0*i/4031.0+1;
    //double wl = 9.0*i/4031.0+1;//angstrom
    
    //xsect1[i] = pc->crossSectionNonOriented(ekin);
    //xsect2[i] = pc_b ->crossSectionNonOriented(ekin);
    //xabs[i]= abs->crossSectionNonOriented(ekin);
    //salida.xsect[i]=xsect2[i]-xsect1[i]+xabs[i];
    //salida.xsect[i]= pc_g->crossSectionNonOriented(ekin)+xabs[i];
    fprintf(file4,"%f\t%f\t%f\t%f\t%f\n",i, pc->crossSectionNonOriented(ekin), pc_g->crossSectionNonOriented(ekin),abs->crossSectionNonOriented(ekin),pc_b->crossSectionNonOriented(ekin)+abs->crossSectionNonOriented(ekin));
    //fprintf(file4,"%f\t%f\n",i,pc_b->crossSectionNonOriented(ekin)+abs->crossSectionNonOriented(ekin));
  }
  fclose(file4);


  //Obtener algunos parametros
  //salida.density= inf-> getDensity();
  //salida.temp = inf ->getTemperature();
  //salida.temp_d=  inf->getDebyeTemperature();

  //Obtener informacion de la estructura

  // Dejo por aca la definicion de la estructura
 /*
    struct NCRYSTAL_API StructureInfo {
    unsigned spacegroup;//From 1-230 if provided, 0 if information not available
    double lattice_a;//angstrom
    double lattice_b;//angstrom
    double lattice_c;//angstrom
    double alpha;//degree
    double beta;//degree
    double gamma;//degree
    double volume;//Aa^3
    unsigned n_atoms;//Number of atoms per unit cell
  };*/

/*
const NCrystal::StructureInfo info= inf->getStructureInfo() ;

// Ahora se llama cualquier parametro como info.alpha

//Me canse y corro el programa desde la consola
system("bash setup.sh");
system("ncrystal_inspectfile --dump /home/chang/Desktop/Original/Instalacion/data/Bi.ncmat >> dump.txt");

//NCrystal::dump(inf); //Deberia haber utilizado esta funcion

FILE * file=fopen ("dump.txt","r");
char line [200];

// Todo lo siguiente para llegar a la fila deseada
char label []= "ABC";
std::string str2= "HKL";
std::string str1 =label;
do{

fgets(line, sizeof(line), file);
strncpy(label, strtok(line, " "),3);
str1 =label;

}while(str2.compare(str1) !=0);
// Desprecio otra fila mas
fgets(line, sizeof(line), file);

//y ahora si voy con el codigo
 
double h [48];
double k [48];
double l [48];
double d_hkl [48];
double mult [48];
double F [48];




for (int i = 0; i < 48; ++i)
{
  fgets(line, sizeof(line), file);  
  char *ptr=line;
  salida.h[i]=strtod(strtok(line, " "),&ptr);
  salida.k[i]=strtod(strtok(NULL, " "),&ptr);
  salida.l[i]=strtod(strtok(NULL, " "),&ptr);
  salida.d_hkl[i]=strtod(strtok(NULL, " "),&ptr);
  salida.mult[i]=strtod(strtok(NULL, " "),&ptr);
  salida.F[i]=strtod(strtok(NULL, " "),&ptr);
  
}
salida.volume=info.volume;
salida.n_atoms=info.n_atoms;
salida.spacegroup=info.spacegroup;

//Bueno, vamos a guardar el archivo

FILE *estructura;
estructura=fopen("salida.txt","a");
for (int i = 0; i < 48; ++i)
{
  fprintf(estructura, "%f\t%f\t%f\t%f\t%f\t%f\n",salida.mult[i],salida.h[i],salida.k[i],salida.l[i],salida.d_hkl[i],salida.F[i]);
}
fprintf(estructura, "%f\t%d\t%f\n",salida.volume, salida.n_atoms, salida.density);
fprintf(estructura, "%f\t%f\t%d\n",salida.temp, salida.temp_d, salida.spacegroup );
for (int i = 0; i < 4031; ++i)
{
  fprintf(estructura, "%f\t%f\n",salida.lam[i], salida.xsect[i]);
}


fclose(estructura);

*/

  return 0;

}

