#!/bin/bash

##########################################################################
# Source this file to undo effect of sourcing setup.sh in same directory #
##########################################################################

function ncrystal_prunepath() {
    P=$(IFS=:;for p in ${!1}; do [[ $p != ${2}* ]] && echo -n ":$p" || :; done)
    export $1=${P:1:99999}
}

NCRYSTAL_THISDIR="$( cd -P "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

if [ ! -z {NCRYSTALDIR:-} -a "x$NCRYSTALDIR" == "x$NCRYSTAL_THISDIR" ]; then
    ncrystal_prunepath PATH "$NCRYSTALDIR"
    ncrystal_prunepath LD_LIBRARY_PATH "$NCRYSTALDIR"
    ncrystal_prunepath DYLD_LIBRARY_PATH "$NCRYSTALDIR"
    ncrystal_prunepath PYTHONPATH "$NCRYSTALDIR"
    unset NCRYSTALDIR
fi

unset ncrystal_prunepath
unset NCRYSTAL_THISDIR
