#!/bin/bash

#################################################
# Source this file to use NCrystal installation #
#################################################

#First undo effect of previously sourcing a setup.sh file from this or another
#NCrystal installation:

function ncrystal_prunepath() {
    P=$(IFS=:;for p in ${!1}; do [[ $p != ${2}* ]] && echo -n ":$p" || :; done)
    export $1=${P:1:99999}
}

if [ ! -z ${NCRYSTALDIR:-} ]; then
    ncrystal_prunepath PATH "$NCRYSTALDIR"
    ncrystal_prunepath LD_LIBRARY_PATH "$NCRYSTALDIR"
    ncrystal_prunepath DYLD_LIBRARY_PATH "$NCRYSTALDIR"
    ncrystal_prunepath PYTHONPATH "$NCRYSTALDIR"
fi

unset ncrystal_prunepath

#Then add this installation (we leave NCRYSTAL_LIB or NCRYSTAL_DATADIR unset
#since they are not actually needed for a standard installation to work out of
#the box - they merely exists as optional features):
export NCRYSTALDIR="$( cd -P "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
export PATH="$NCRYSTALDIR/bin:$PATH"
export LD_LIBRARY_PATH="$NCRYSTALDIR/lib:$LD_LIBRARY_PATH"
export DYLD_LIBRARY_PATH="$NCRYSTALDIR/lib:$DYLD_LIBRARY_PATH"
if [ -f $NCRYSTALDIR/python/NCrystal/__init__.py ]; then
    export PYTHONPATH="$NCRYSTALDIR/python:$PYTHONPATH"
fi
