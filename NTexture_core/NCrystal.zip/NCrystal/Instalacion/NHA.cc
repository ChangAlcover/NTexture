#include <math.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <stdio.h>
#include <iostream>
#include "/home/chang/Documents/Original/ncrystal-1.0.0/ncrystal_core/src/NCNeutronSCL.hh"


using namespace std;



int main (int argc, char* argv[])
{
	//Crear una instncia del NCrystal->NeutronSCL para llamar al constructor
	const NCrystal::NeutronSCL *x=NCrystal::NeutronSCL::instance();
	double b_coh_h=0, A_h=0, coh_h=0, inc_h=0, abs_h=0;
	for (int i = 0; i < (argc-9)/2; ++i)
	{
		b_coh_h= b_coh_h+x->getCoherentSL(argv[i*2+9])*std::stod(argv[i*2+10]);  //b_coh=SUM (C_k*b_coh_k)
		coh_h=coh_h+x->getCoherentSL(argv[i*2+9])*std::stod(argv[i*2+10]); //Sigma_coh=SUM(C_k*b_coh_k)^2
		abs_h=abs_h+std::stod(argv[i*2+10])*x->getCaptureXS(argv[i*2+9]);  //sigma_abs=SUM (C_k*sigma_abs_k)
	}
	coh_h=coh_h*coh_h*4*3.1415;                      //Ahora la multiplicacion por 4pi
	for (int i = 0; i < (argc-9)/2; ++i)
	{
		inc_h=inc_h+(x->getIncoherentXS(argv[i*2+9])+x->getCoherentXS(argv[i*2+9]))*std::stod(argv[i*2+10]); //sigma_inc=SUM (C_k*(sigma_inc_k+sigma_coh_k))-sigma_coh
	}
	inc_h=inc_h-coh_h;
	for (int i = 0; i < (argc-9)/2; ++i)
	{
		A_h=A_h+std::stod(argv[i*2+10])*(x->getIncoherentXS(argv[i*2+9])+x->getCoherentXS(argv[i*2+9]))/(pow(1.0+1.0/(x->getAtomicMass(argv[i*2+9])),2.0));
	}
	A_h=1.0/(sqrt((inc_h+coh_h)/A_h)-1.0);

	printf("b_coh=%f, inc=%f, abs=%f, A=%f\n",b_coh_h,inc_h,abs_h, A_h );
	
	// Vamos a guardar y pedir los parametros necesarios

	FILE *salida;
	salida=fopen ("New_material.nxs","a");

	fprintf(salida, "space_group = %s\n", argv[1]);
	fprintf(salida, "lattice_a = %s\n", argv[2] );
	fprintf(salida, "lattice_b = %s\n", argv[3] );
	fprintf(salida, "lattice_c = %s\n", argv[4] );
	fprintf(salida, "lattice_alpha = %s\n",argv[5] );
	fprintf(salida, "lattice_beta = %s\n", argv[6] );
	fprintf(salida, "lattice_gamma = %s\n", argv[7] );
	fprintf(salida, "debye_temp = %s\n", argv[8] );

	//Ahora agrego los atomos segun su posicion de Wyckoff
	// Name (String), b_coh, sigma_inc, sigma_abs_2200, Molar mass, x,y,z,atomic_number
	fprintf(salida, "add_atom= X %f %f %f %f 0 0 0 %f \n", b_coh_h*10, inc_h/10, abs_h, A_h,A_h/2 );

	//vERSION WITH DATA.TXT
	/*
	
	FILE* file;
	char line [200];


	double Z [argc/2];
	double b_coh[argc/2];
	double A [argc/2];
	double coh [argc/2];
	double inc [argc/2];
	double abs[argc/2];

	char label[]="Fe";

	for (int i = 0; i < argc/2; ++i)
	{
		file=fopen("Data.txt","r");
		fgets(line,sizeof(line),file);
		char *ptr=line;	
		
		strncpy(label, strtok(line, "\t"),2);

		std::string str1=label;
		std::string str2=argv[i*2+1];


		while(str1.compare(str2) !=0)
		{
			fgets(line,sizeof(line),file);	
			
			strncpy(label, strtok(line, "\t"),2);			
			Z[i]=strtod(strtok(NULL,"\t"),&ptr);
			b_coh[i]=strtod(strtok(NULL,"\t"),&ptr);
			A[i]=strtod(strtok(NULL,"\t"),&ptr);
			coh[i]=strtod(strtok(NULL,"\t"),&ptr);
			inc[i]=strtod(strtok(NULL,"\t"),&ptr);
			abs[i]=strtod(strtok(NULL,"\t"),&ptr);

			str1=label;
			str2=argv[i*2+1];
		}
	}

	double b_coh_h=0, A_h=0, coh_h=0, inc_h=0, abs_h=0;
	for (int i = 0; i < argc/2; ++i)
	{
		b_coh_h= b_coh_h+std::stod(argv[i*2+2])*b_coh[i];
		coh_h=coh_h+std::stod(argv[i*2+2])*b_coh[i]*b_coh[i]*std::stod(argv[i*2+2])*4*3.1415;
		abs_h=abs_h+std::stod(argv[i*2+2])*abs[i];
	}
	for (int i = 0; i < argc/2; ++i)
	{
		//inc_h=inc_h+inc[i]+coh[i];
		inc_h=inc_h+inc[i]+std::stod(argv[i*2+2])*b_coh[i]*b_coh[i]*std::stod(argv[i*2+2])*4*3.1415;
	}
	inc_h=inc_h-coh_h;
	for (int i = 0; i < argc/2; ++i)
	{
		A_h=std::stod(argv[i*2+2])*(inc[i]+coh[i])/(pow((1+1/A[i]),2));
	}
	A_h=1/(sqrt((inc_h+coh_h)/A_h)-1);

	printf("%f %f %f %f\n",b_coh_h,coh_h,inc_h, A_h );
	
	*/

}
