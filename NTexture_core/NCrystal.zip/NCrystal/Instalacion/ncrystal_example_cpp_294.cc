

#include "include/NCrystal/NCrystal.hh"
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <math.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <stdio.h>

using namespace std;
struct Salida {
    double h [48];
    double k [48];
    double l [48];
    double d_hkl [48];
    double mult [48];
    double F [48];
    double volume;
    unsigned n_atoms;
    double density;
    double temp;
    double temp_d;
    unsigned spacegroup;
    double lam [4031];
    double xsect [4031];
    double no_el_coh[4031];
    double el_coh[4031];
  };



int main (){

  Salida salida;

  //Crear el objeto cfg sin las componentes de bragg
  NCrystal::MatCfg cfg("C_sg194_pyrolytic_graphite.nxs;dcutoff=0.5; bkgd=false");
  NCrystal::MatCfg cfg_o("C_sg194_pyrolytic_graphite.nxs;dcutoff=0.5; bragg=false");
  NCrystal::MatCfg cfg_t("C_sg194_pyrolytic_graphite.nxs;dcutoff=0.5");

  //Crear las instancias de scaterring y de absorcion
  const NCrystal::Absorption * abs= NCrystal::createAbsorption(cfg_o);
  const NCrystal::Scatter * pc_t =  NCrystal::createScatter( cfg_t);
  const NCrystal::Scatter * pc_bkg =  NCrystal::createScatter( cfg);
  const NCrystal::Scatter * pc_bragg =  NCrystal::createScatter( cfg_o);
  const NCrystal::Info * inf =  NCrystal::createInfo(cfg);  

  //Cargo las longitudes de onda

  FILE * file=fopen ("long_294.txt","r");
  char line [100];
  double lam;

  //la nueva seccion eficaz
  double xsect[294];

  FILE * file2 =fopen("/home/chang/Desktop/RAFA/Cu_Ncrystal.txt", "a");

  for (int i = 1; i < 295; ++i)
  {
    fgets(line, sizeof(line),file);
    char *ptr=line;
    lam=strtod(strtok(line,"\n"),&ptr);
    double ekin =NCrystal::wl2ekin(lam);
    //xsect[i]=pc->crossSectionNonOriented(ekin)+abs->crossSectionNonOriented(ekin);

    fprintf(file2, "%f\t%f\t%f\n",abs->crossSectionNonOriented(ekin),pc_bragg->crossSectionNonOriented(ekin), pc_bkg->crossSectionNonOriented(ekin));
  }

  fclose(file);
  fclose(file2);
/*

  //A partir de aqui es nuevo, para generar el .mat

  salida.density= inf-> getDensity();
  salida.temp = inf ->getTemperature();
  salida.temp_d=  inf->getDebyeTemperature();

  const NCrystal::StructureInfo info= inf->getStructureInfo() ;
  system("bash setup.sh");
  system("ncrystal_inspectfile --dump Cu_sg225.nxs >> dump.txt");

  FILE * file3=fopen ("dump.txt","r");
  char line2 [200];
  char label []= "ABC";
  std::string str2= "HKL";
  std::string str1 =label;
  do{

  fgets(line2, sizeof(line2), file3);
  strncpy(label, strtok(line2, " "),3);
  str1 =label;

  }while(str2.compare(str1) !=0);
  fgets(line2, sizeof(line2), file3);


for (int i = 0; i < 48; ++i)
{
  fgets(line2, sizeof(line2), file3);  
  char *ptr=line2;
  salida.h[i]=strtod(strtok(line2, " "),&ptr);
  salida.k[i]=strtod(strtok(NULL, " "),&ptr);
  salida.l[i]=strtod(strtok(NULL, " "),&ptr);
  salida.d_hkl[i]=strtod(strtok(NULL, " "),&ptr);
  salida.mult[i]=strtod(strtok(NULL, " "),&ptr);
  salida.F[i]=strtod(strtok(NULL, " "),&ptr);
  
}
salida.volume=info.volume;
salida.n_atoms=info.n_atoms;
salida.spacegroup=info.spacegroup;

for (int i = 0; i < 4031; ++i)
  {
    salida.lam[i]=6.0*i/4031.0;
    double wl = 6.0*i/4031.0;//angstrom
    double ekin = NCrystal::wl2ekin(wl);
    salida.xsect[i]= pc_t->crossSectionNonOriented(ekin)+abs->crossSectionNonOriented(ekin);
    salida.no_el_coh[i]=abs->crossSectionNonOriented(ekin)+pc_bragg->crossSectionNonOriented(ekin);
    salida.el_coh[i]=abs->crossSectionNonOriented(ekin)+pc_bkg->crossSectionNonOriented(ekin);
  }


FILE *estructura;
estructura=fopen("salida.txt","a");
for (int i = 0; i < 48; ++i)
{
  fprintf(estructura, "%f\t%f\t%f\t%f\t%f\t%f\n",salida.mult[i],salida.h[i],salida.k[i],salida.l[i],salida.d_hkl[i],salida.F[i]);
}
fprintf(estructura, "%f\t%d\t%f\n",salida.volume, salida.n_atoms, salida.density);
fprintf(estructura, "%f\t%f\t%d\n",salida.temp, salida.temp_d, salida.spacegroup );
for (int i = 0; i < 4031; ++i)
{
  fprintf(estructura, "%f\t%f\t%f\t%f\n",salida.lam[i], salida.xsect[i],salida.no_el_coh[i],salida.el_coh[i]);
}


fclose(estructura);
  return 0;

}

*/