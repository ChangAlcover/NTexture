import scipy.io 


mat=scipy.io.loadmat('aleacion_Al.mat')

hkl = mat['hkl']
sample=mat['sample']
stot=mat['stot']

#Estructura HKL, debe ser de la forma hkl[0][0][x][i]
#Donde x es la variable a modificar en el orden:
#multiplicity, h, k, l, d, F^2, cell_vol, n_atoms, G, ref
#i es el indice de la variable, usualmente 48


datos1= []
datos2= []
datos3= []
cpp=open("salida.txt","r")
for line in cpp:
	s=line.split('\t')
	if len(s)==6:
		datos1.append(s)
	if len(s)==4:
		datos2.append(s)
	if len(s)==3:
		datos3.append(s)

# Asgnacion de valores a Multiplicity, h, k,l,d,f
for i in range(0,48):
	hkl[0][0][0][i]=float(datos1[i][0])
	hkl[0][0][1][i]=float(datos1[i][1])
	hkl[0][0][2][i]=float(datos1[i][2])
	hkl[0][0][3][i]=float(datos1[i][3])
	hkl[0][0][4][i]=float(datos1[i][4])
	hkl[0][0][5][i]=float(datos1[i][5])
	pass

# Ahora asigno cell_vol y N_atoms in cell
hkl[0][0][6][0]=datos3[0][0]
hkl[0][0][7][0]=datos3[0][1]


#Me falta limpiar las G_hkl y ref

#for i in range(0,48):
#	hkl[0][0][8][0][i]=0
#	pass
#hkl[0][0][9][0]=0

# Ahora voy para la estrucutura sample

sample[0][0][0][0]='New_material'
# por ahora no cambio el sample[0][0][1][0], que es el parametro de red
sample[0][0][2][0]=float(datos3[1][0]) #temperatura
sample[0][0][3][0]=float(datos3[0][0])	#volumen
sample[0][0][4][0]=float(datos3[0][1]) #atoms in cell
sample[0][0][5][0]=float(datos3[0][2]) #densidad
sample[0][0][7][0]=float(datos3[1][1]) #Temp Debye
sample[0][0][9][0]=float(datos3[1][2]) #Grupo de simetria

#Vamos ahora son stot
for i in range(0,4031):
	stot[0][0][0][0][i]=datos2[i][0]
	stot[0][0][1][0][i]=datos2[i][1]
	#Ahora borro el resto de los archivos en el arreglo
	stot[0][0][2][0][i]=datos2[i][2]
	stot[0][0][3][0][i]=datos2[i][3]
	pass



# Finalmente guardo el archivo
scipy.io.savemat('New_material.mat',{'mat':mat})
