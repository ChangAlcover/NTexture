#Para C++
#g++ -o NHA NHA.cc -L/home/chang/Downloads/ncrystal-1.0.0/ -lNCrystal
#export LD_LIBRARY_PATH="/home/chang/Downloads/ncrystal-1.0.0/:LD_LIBRARY_PATH"

#Es necesario introducir 7 parametros iniciales:
#Grupo de simetria, caracteristicas de la red: a,b,c,alpha,beta,gamma y Temperatura de Debye
#Luego cada elemento seguido de su fraccion en peso

#Aluminio de la tesis
#./NHA 225 4.132 4.132 4.132 90 90 90 410 Al 0.8628 Zn 0.069 Mg 0.027 Cu 0.025 Si 0.0012 Fe 0.015

#Para buscar grupo espacial Crystallography open database
#./NHA 225 5.410 5.410 5.410 90 90 90 295 Ce 0.814 O 0.186

#Aleacion de la tesis
#./NHA 229 2.8665 2.8665 2.8665 90 90 90 443.9152 Fe 0.99715 C 0.00004 Mn 0.0017 Al 0.00045 Si 0.0003

export LD_LIBRARY_PATH="/home/chang/Desktop/NTexture/NCrystal/ncrystal-1.0.0/:LD_LIBRARY_PATH"
. /home/chang/Desktop/NTexture/NCrystal/Instalacion/setup.sh
#g++ -fpic -shared -o example libcpp.so ncrystal_example_cpp.cc -L/home/chang/Documents/Original/ncrystal-1.0.0 -lNCrystal

g++ -o example ncrystal_example_cpp.cc -L/home/chang/Desktop/NTexture/NCrystal/ncrystal-1.0.0 -lNCrystal
#g++ -o example ncrystal_example_cpp.cc -L/home/chang/Documents/Original/ncrystal-1.0.0 -lNCrystal
./example 

 #python3 Load.py


#Eliminar archivos creados

#rm -- salida.txt
#rm -- dump.txt
